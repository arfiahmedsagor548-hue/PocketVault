# PocketVault — Smart Mobile Backup & Restore (Android / Kotlin / Jetpack Compose)

PocketVault is a native Android backup and restoration application built with **Kotlin**, **Jetpack Compose (Material 3)**, **Google Drive API v3**, **Zip4j (streaming + AES-256)**, **Room**, **WorkManager**, and **Android Keystore**.

It scans accessible mobile categories (Photos, Videos, Screenshots, Audio, Voice Recordings, Documents, Downloads, Other Files, User-Selected SAF Folders, Contacts `.vcf`, and Calendar `.ics`), packages them into verifiable split ZIP archives with file-level **SHA-256** checksums, uploads them directly to the user's own Google Drive inside `PocketVault Backups/<Device_Name>/<Timestamp>/`, and restores them reliably on a factory-reset or replacement phone.

## 1. Beginner-Friendly Step-by-Step Build Roadmap

If this is your first Android app, you do not have to write all 13 screens at once. The codebase is organized into 4 progressive phases so you can test each milestone right away:

* **Phase 1 — Core MVP (Try Right Away)**: Open the project in Android Studio and run it on an emulator or phone. The **Dashboard**, **Mobile Storage Scanner**, and **Category-Wise ZIP Engine** work immediately on local storage even before you set up Google Cloud OAuth.
* **Phase 2 — High-Priority Restore & Verification**: Test the **Restore Preview**, **SHA-256 Integrity Check**, **Zip-Slip Path Traversal Guard**, and **Conflict Resolution** (`Keep Existing`, `Rename Restored Copy`, `Skip`, or `Replace After Confirmation`).
* **Phase 3 — Contacts, Calendar, AES-256 Encryption & App Inventory**: Enable **Contacts (`.vcf`)**, **Calendar (`.ics`)**, **Zip4j AES-256 Encryption**, and the **Installed App Inventory Report** with Google Play Store links.
* **Phase 4 — Direct Google Drive API v3 & WorkManager Scheduling**: Connect your Google Cloud OAuth Client ID for resumable cloud uploads, cross-device snapshot discovery, and scheduled Wi-Fi/Charging background backups.

## 2. Project Architecture

```text
PocketVault/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── res/
        │   │   ├── values/strings.xml          (English localization)
        │   │   ├── values/themes.xml           (Deep Teal status/nav bars)
        │   │   └── values-bn/strings.xml       (Bangla / বাংলা localization)
        │   └── java/com/pocketvault/backup/
        │       ├── PocketVaultApp.kt
        │       ├── MainActivity.kt
        │       ├── domain/model/BackupModels.kt
        │       ├── data/
        │       │   ├── security/
        │       │   │   ├── ChecksumUtils.kt
        │       │   │   └── VaultSecurityManager.kt
        │       │   ├── local/
        │       │   │   └── PocketVaultDatabase.kt
        │       │   ├── scanner/
        │       │   │   ├── MobileStorageScanner.kt
        │       │   │   ├── ContactsCalendarExporter.kt
        │       │   │   └── AppInventoryManager.kt
        │       │   ├── zip/
        │       │   │   ├── SmartZipBackupEngine.kt
        │       │   │   ├── SmartZipRestoreEngine.kt
        │       │   │   └── BackupReportGenerator.kt
        │       │   └── drive/
        │       │       └── GoogleDriveRepository.kt
        │       ├── worker/
        │       │   └── BackupWorker.kt
        │       └── ui/
        │           ├── PocketVaultViewModel.kt
        │           ├── theme/VaultTheme.kt
        │           ├── components/VaultComponents.kt
        │           └── screens/PocketVaultScreens.kt
        └── test/java/com/pocketvault/backup/
            └── SmartZipEngineAndRestoreTest.kt
```

## 3. Google Cloud Project, SHA-1 Certificate & OAuth 2.0 Setup

PocketVault never uses hardcoded OAuth secrets or fake login screens. To enable live Google Drive uploads:

1. **Get your Debug SHA-1 Fingerprint**:
   Run the following command in your project terminal (or Android Studio Gradle panel):
   ```bash
   ./gradlew signingReport
   ```
   Copy the `SHA1` fingerprint listed under `Variant: debugUnitTest` / `debug`.

2. **Configure Google Cloud Console**:
   * Open the [Google Cloud Console](https://console.cloud.google.com/) and create a project named `PocketVault`.
   * Go to **APIs & Services → Library** and enable the **Google Drive API**.
   * Go to **APIs & Services → OAuth consent screen**:
     * Choose **External** (or Internal for Workspace testing).
     * Add the minimum required scope: `https://www.googleapis.com/auth/drive.file` (allows access *only* to folders and archives created by PocketVault).
     * Add your Google email under **Test users**.
   * Go to **APIs & Services → Credentials → Create Credentials → OAuth client ID**:
     * Application type: **Android**
     * Package name: `com.pocketvault.backup`
     * SHA-1 certificate fingerprint: Paste the SHA-1 from step 1.

3. **Pass Client ID in `gradle.properties` or `local.properties` (Optional for token verification)**:
   ```properties
   POCKETVAULT_GOOGLE_OAUTH_CLIENT_ID=your-client-id.apps.googleusercontent.com
   ```

## 4. Building, Testing & Installing a Debug APK

1. **Run Unit Tests (ZIP Engine, AES-256, SHA-256, Conflict Resolution & Manifest)**:
   ```bash
   ./gradlew testDebugUnitTest
   ```
2. **Build the Debug APK**:
   ```bash
   ./gradlew assembleDebug
   ```
   The compiled APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`
3. **Install onto a Connected Android Phone via ADB**:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## 5. Privacy, Permissions & Known Platform Limitations

* **Least-Privilege Permissions**: Uses `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, and `READ_MEDIA_AUDIO` on Android 13+ (`READ_EXTERNAL_STORAGE` on Android 12 and below), Storage Access Framework (`OpenDocumentTree`) for custom folders, `READ_CONTACTS`/`WRITE_CONTACTS` for `.vcf` exports, and `READ_CALENDAR`/`WRITE_CALENDAR` for `.ics` exports.
* **Protected App Sandbox Restrictions**: Android security isolates private application databases (`/data/data/<package>`), banking sessions, hardware-backed authenticator secrets, and encrypted messaging databases from third-party apps. PocketVault never uses root exploits or hidden APIs; instead, it generates an **Installed App Inventory** with version numbers and official Google Play Store links and guides users to Android's system backup for app-private settings.
* **SMS/MMS & Call Logs**: Restricted by Google Play policy to apps holding the default SMS/Phone handler role or eligible enterprise/sideload distributions; PocketVault clearly marks this category as policy-gated unless permission is granted.
