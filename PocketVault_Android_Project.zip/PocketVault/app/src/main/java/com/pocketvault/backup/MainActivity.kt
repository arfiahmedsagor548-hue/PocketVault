package com.pocketvault.backup

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.pocketvault.backup.ui.PocketVaultViewModel
import com.pocketvault.backup.ui.screens.PocketVaultRootScreen
import com.pocketvault.backup.ui.theme.PocketVaultTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PocketVaultViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            PocketVaultTheme {
                val uiState by viewModel.uiState.collectAsState()
                val snapshots by viewModel.localSnapshots.collectAsState()
                val logs by viewModel.operationLogs.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    viewModel.refreshAccountAndScan()
                }

                val safFolderLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocumentTree()
                ) { treeUri ->
                    if (treeUri != null) {
                        contentResolver.takePersistableUriPermission(
                            treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                        viewModel.addCustomSafFolder(treeUri)
                    }
                }

                val googleSignInLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    runCatching {
                        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                        val account = task.result
                        if (account != null) {
                            viewModel.securityManager.connectedAccountEmail = account.email
                        }
                    }
                    viewModel.refreshAccountAndScan()
                }

                PocketVaultRootScreen(
                    uiState = uiState,
                    snapshots = snapshots,
                    logs = logs,
                    onNavigate = viewModel::navigateTo,
                    onToggleLanguage = viewModel::toggleLanguage,
                    onRequestPermissions = {
                        val perms = buildList {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                add(Manifest.permission.READ_MEDIA_IMAGES)
                                add(Manifest.permission.READ_MEDIA_VIDEO)
                                add(Manifest.permission.READ_MEDIA_AUDIO)
                                add(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                add(Manifest.permission.READ_EXTERNAL_STORAGE)
                            }
                            add(Manifest.permission.READ_CONTACTS)
                            add(Manifest.permission.WRITE_CONTACTS)
                            add(Manifest.permission.READ_CALENDAR)
                            add(Manifest.permission.WRITE_CALENDAR)
                        }.toTypedArray()
                        permissionLauncher.launch(perms)
                    },
                    onPickSafFolder = { safFolderLauncher.launch(null) },
                    onConnectGoogleDrive = {
                        val signInIntent = viewModel.driveRepository.buildGoogleSignInClient().signInIntent
                        googleSignInLauncher.launch(signInIntent)
                    },
                    onDisconnectGoogleDrive = viewModel::disconnectGoogleAccount,
                    onToggleCategory = viewModel::toggleCategorySelection,
                    onInspectCategory = viewModel::openCategoryInExplorer,
                    onUpdateConfig = viewModel::updateBackupConfiguration,
                    onStartBackup = viewModel::startRealBackup,
                    onPauseResume = viewModel::pauseOrResumeActiveTask,
                    onCancelTask = viewModel::cancelActiveTask,
                    onRefreshRemoteSnapshots = viewModel::discoverCloudBackupsForRestore,
                    onSelectConflictStrategy = viewModel::updateConflictStrategy
                )
            }
        }
    }
}
