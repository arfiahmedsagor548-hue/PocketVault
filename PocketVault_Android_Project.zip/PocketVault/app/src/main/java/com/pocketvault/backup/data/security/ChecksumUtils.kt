package com.pocketvault.backup.data.security

import java.io.File
import java.io.InputStream
import java.security.MessageDigest

object ChecksumUtils {
    private const val BUFFER_SIZE = 64 * 1024

    fun computeSha256(inputStream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        var bytesRead: Int
        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
            digest.update(buffer, 0, bytesRead)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun computeFileSha256(file: File): String {
        file.inputStream().buffered().use { stream ->
            return computeSha256(stream)
        }
    }

    fun verifyFileSha256(file: File, expectedHex: String): Boolean {
        if (!file.exists() || expectedHex.isBlank()) return false
        val actualHex = computeFileSha256(file)
        return actualHex.equals(expectedHex.trim(), ignoreCase = true)
    }
}
