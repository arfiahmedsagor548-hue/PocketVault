package com.pocketvault.backup.data.zip

import com.pocketvault.backup.domain.model.BackupManifest
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Generates human-readable backup_report.html and machine-verifiable backup_manifest.json.
 * Never embeds passwords, OAuth access tokens, or secret keys.
 */
object BackupReportGenerator {

    private val prettyJson = Json {
        prettyPrint = true
        encodeDefaults = true
        ignoreUnknownKeys = true
    }

    fun writeManifestJson(manifest: BackupManifest, outputFile: File): String {
        val jsonText = prettyJson.encodeToString(manifest)
        outputFile.writeText(jsonText, Charsets.UTF_8)
        return jsonText
    }

    fun parseManifestJson(jsonString: String): BackupManifest {
        return prettyJson.decodeFromString(jsonString)
    }

    fun writeBackupReportHtml(manifest: BackupManifest, outputFile: File) {
        val html = buildString {
            appendLine("<!DOCTYPE html>")
            appendLine("<html lang='en'><head><meta charset='UTF-8'>")
            appendLine("<meta name='viewport' content='width=device-width, initial-scale=1.0'>")
            appendLine("<title>PocketVault Backup Report — ${manifest.backupId}</title>")
            appendLine("<style>")
            appendLine("body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #E4F7F1; color: #123B38; margin: 0; padding: 24px; }")
            appendLine(".header { background: #063C3D; color: #FFFFFF; padding: 24px; border-radius: 16px; margin-bottom: 20px; }")
            appendLine(".card { background: #FFFFFF; padding: 20px; border-radius: 14px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(6,60,61,0.08); }")
            appendLine(".badge { display: inline-block; padding: 4px 12px; border-radius: 999px; background: #27AE83; color: #FFFFFF; font-size: 12px; font-weight: 600; }")
            appendLine("table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }")
            appendLine("th, td { text-align: left; padding: 10px; border-bottom: 1px solid #E4F7F1; }")
            appendLine("th { background: #042F31; color: #CFFFF0; }")
            appendLine("code { font-family: monospace; font-size: 11px; color: #063C3D; }")
            appendLine("</style></head><body>")
            appendLine("<div class='header'>")
            appendLine("<h1>PocketVault — Backup Verification Report</h1>")
            appendLine("<p>Snapshot ID: <strong>${manifest.backupId}</strong> | Device: <strong>${manifest.deviceLabel}</strong> (Android ${manifest.androidRelease})</p>")
            appendLine("<p>Created: ${manifest.createdAtIso} | Encryption: <strong>${if (manifest.encryptedAes256) "AES-256 Enabled" else "Standard Unencrypted ZIP"}</strong></p>")
            appendLine("</div>")

            appendLine("<div class='card'>")
            appendLine("<h2>Archive Parts &amp; Integrity Status</h2>")
            appendLine("<table><thead><tr><th>Archive Name</th><th>Category</th><th>Size (Bytes)</th><th>SHA-256 Checksum</th><th>Status</th></tr></thead><tbody>")
            manifest.archives.forEach { arch ->
                appendLine("<tr><td>${arch.archiveName}</td><td>${arch.categoryId}</td><td>${arch.sizeBytes}</td><td><code>${arch.sha256Checksum}</code></td><td><span class='badge'>${if (arch.verified) "VERIFIED" else "PENDING"}</span></td></tr>")
            }
            appendLine("</tbody></table></div>")

            appendLine("<div class='card'>")
            appendLine("<h2>Skipped / Excluded Items (${manifest.skippedFiles.size})</h2>")
            if (manifest.skippedFiles.isEmpty()) {
                appendLine("<p>All selected files were processed without skips.</p>")
            } else {
                appendLine("<table><thead><tr><th>Relative Path</th><th>Category</th><th>Reason</th></tr></thead><tbody>")
                manifest.skippedFiles.forEach { skip ->
                    appendLine("<tr><td>${skip.relativePath}</td><td>${skip.categoryId}</td><td>${skip.reason}</td></tr>")
                }
                appendLine("</tbody></table>")
            }
            appendLine("</div>")

            if (manifest.appInventory.isNotEmpty()) {
                appendLine("<div class='card'>")
                appendLine("<h2>Installed Application Inventory (${manifest.appInventory.size} Apps)</h2>")
                appendLine("<p><em>Note: Android security isolates private application databases and banking/authenticator sessions. Use the official Play Store links below to reinstall apps on a replacement phone.</em></p>")
                appendLine("<table><thead><tr><th>Application</th><th>Package</th><th>Version</th><th>Store Link</th></tr></thead><tbody>")
                manifest.appInventory.forEach { app ->
                    appendLine("<tr><td>${app.appName}</td><td><code>${app.packageName}</code></td><td>${app.versionName}</td><td><a href='${app.playStoreUrl}'>Google Play</a></td></tr>")
                }
                appendLine("</tbody></table></div>")
            }
            appendLine("</body></html>")
        }
        outputFile.writeText(html, Charsets.UTF_8)
    }
}
