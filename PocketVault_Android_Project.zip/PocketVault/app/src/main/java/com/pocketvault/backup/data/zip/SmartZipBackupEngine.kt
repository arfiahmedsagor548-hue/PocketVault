package com.pocketvault.backup.data.zip

import android.content.Context
import android.net.Uri
import com.pocketvault.backup.data.local.IncrementalFileCacheEntity
import com.pocketvault.backup.data.local.PocketVaultDao
import com.pocketvault.backup.data.security.ChecksumUtils
import com.pocketvault.backup.domain.model.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import java.io.File
import java.io.InputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Category-wise streaming ZIP backup engine with:
 * - Configurable archive splitting (e.g., Photos_001.zip, Photos_002.zip)
 * - Smart STORE mode for pre-compressed media (.jpg, .mp4, .mp3, .pdf) to avoid wasted CPU
 * - Standard AES-256 encryption via Zip4j when enabled
 * - File-level SHA-256 checksum calculation and deduplication
 * - Pause, resume, and cancel support without deleting local originals
 */
class SmartZipBackupEngine(
    private val context: Context,
    private val dao: PocketVaultDao? = null
) {
    private val pausedFlag = AtomicBoolean(false)
    private val cancelledFlag = AtomicBoolean(false)

    private val alreadyCompressedExtensions = setOf(
        "jpg", "jpeg", "png", "webp", "heic", "mp4", "mkv", "mov", "mp3", "aac", "ogg", "flac", "zip", "pdf", "docx", "xlsx", "pptx"
    )

    fun setPaused(paused: Boolean) {
        pausedFlag.set(paused)
    }

    fun cancel() {
        cancelledFlag.set(true)
    }

    data class CategoryZipBuildResult(
        val category: BackupCategory,
        val generatedArchives: List<GeneratedArchivePart>,
        val manifestFileRecords: List<ManifestFileRecord>,
        val skippedFiles: List<SkippedFileRecord>,
        val updatedCacheEntries: List<IncrementalFileCacheEntity>
    )

    data class GeneratedArchivePart(
        val archiveFile: File,
        val category: BackupCategory,
        val partIndex: Int,
        val sizeBytes: Long,
        val sha256Checksum: String,
        val encryptedAes256: Boolean
    )

    suspend fun createCategoryArchives(
        backupId: String,
        category: BackupCategory,
        files: List<ScannedFileItem>,
        stagingDir: File,
        config: BackupConfiguration,
        encryptionPassword: CharArray? = null,
        streamProvider: ((ScannedFileItem) -> InputStream?)? = null,
        onProgress: suspend (completedInCategory: Int, currentFile: String, bytesProcessed: Long) -> Unit
    ): CategoryZipBuildResult {
        stagingDir.mkdirs()
        val generatedParts = mutableListOf<GeneratedArchivePart>()
        val manifestFiles = mutableListOf<ManifestFileRecord>()
        val skipped = mutableListOf<SkippedFileRecord>()
        val cacheUpdates = mutableListOf<IncrementalFileCacheEntity>()
        val seenHashesInCategory = mutableSetOf<String>()

        var currentPartIndex = 1
        var currentPartAccumulatedBytes = 0L
        var currentZipFile: ZipFile? = null
        var currentZipFileRef: File? = null

        fun openOrRotateZipPart(forceNew: Boolean = false): Pair<ZipFile, File> {
            if (!forceNew && currentZipFile != null && currentZipFileRef != null) {
                return currentZipFile!! to currentZipFileRef!!
            }
            currentZipFileRef?.let { completedFile ->
                if (completedFile.exists() && completedFile.length() > 0L) {
                    val sha = ChecksumUtils.computeFileSha256(completedFile)
                    generatedParts.add(
                        GeneratedArchivePart(
                            archiveFile = completedFile,
                            category = category,
                            partIndex = currentPartIndex,
                            sizeBytes = completedFile.length(),
                            sha256Checksum = sha,
                            encryptedAes256 = config.encryptArchives && !encryptionPassword.isNullOrEmpty()
                        )
                    )
                    currentPartIndex++
                }
            }
            val partName = "%s_%03d.zip".format(category.zipPrefix, currentPartIndex)
            val targetFile = File(stagingDir, partName)
            if (targetFile.exists()) targetFile.delete()
            val zip = if (config.encryptArchives && !encryptionPassword.isNullOrEmpty()) {
                ZipFile(targetFile, encryptionPassword)
            } else {
                ZipFile(targetFile)
            }
            currentZipFile = zip
            currentZipFileRef = targetFile
            currentPartAccumulatedBytes = 0L
            return zip to targetFile
        }

        var completedCount = 0
        var totalBytesDone = 0L

        for (item in files) {
            currentCoroutineContext().ensureActive()
            if (cancelledFlag.get()) throw CancellationException("Backup cancelled by user.")
            while (pausedFlag.get()) {
                delay(250)
                if (cancelledFlag.get()) throw CancellationException("Backup cancelled while paused.")
            }

            // Incremental check if mode == INCREMENTAL
            if (config.mode == BackupMode.INCREMENTAL && dao != null) {
                val cached = dao.getCachedFileEntry(item.relativePath, category.id)
                if (cached != null &&
                    cached.sizeBytes == item.sizeBytes &&
                    cached.lastModifiedEpochMillis == item.lastModifiedEpochMillis
                ) {
                    skipped.add(
                        SkippedFileRecord(
                            relativePath = item.relativePath,
                            categoryId = category.id,
                            reason = "Unchanged since snapshot ${cached.lastBackupId} (Incremental skip)"
                        )
                    )
                    completedCount++
                    onProgress(completedCount, item.displayName, totalBytesDone)
                    continue
                }
            }

            try {
                val openInputStream: () -> InputStream? = {
                    if (streamProvider != null) {
                        streamProvider(item)
                    } else {
                        context.contentResolver.openInputStream(Uri.parse(item.contentUriString))
                    }
                }

                // Pass 1: Compute SHA-256 stream checksum
                val sha256 = openInputStream()?.use { stream ->
                    ChecksumUtils.computeSha256(stream)
                } ?: run {
                    skipped.add(
                        SkippedFileRecord(
                            relativePath = item.relativePath,
                            categoryId = category.id,
                            reason = "File disappeared or became inaccessible before archiving"
                        )
                    )
                    continue
                }

                // Deduplication check within category
                val dedupKey = "${item.sizeBytes}:$sha256"
                if (!seenHashesInCategory.add(dedupKey)) {
                    skipped.add(
                        SkippedFileRecord(
                            relativePath = item.relativePath,
                            categoryId = category.id,
                            reason = "Duplicate content detected (SHA-256 match within category)"
                        )
                    )
                    completedCount++
                    continue
                }

                // Rotate archive part if adding this file exceeds maxArchivePartSizeBytes
                val shouldRotate = currentPartAccumulatedBytes > 0L &&
                    (currentPartAccumulatedBytes + item.sizeBytes) > config.maxArchivePartSizeBytes
                val (zipFile, rawFile) = openOrRotateZipPart(forceNew = shouldRotate)

                val ext = item.displayName.substringAfterLast('.', "").lowercase()
                val zipParams = ZipParameters().apply {
                    fileNameInZip = sanitizeRelativeEntryPath(item.relativePath)
                    lastModifiedFileTime = item.lastModifiedEpochMillis
                    if (ext in alreadyCompressedExtensions) {
                        compressionMethod = CompressionMethod.STORE
                    } else {
                        compressionMethod = CompressionMethod.DEFLATE
                        compressionLevel = CompressionLevel.NORMAL
                    }
                    if (config.encryptArchives && !encryptionPassword.isNullOrEmpty()) {
                        isEncryptFiles = true
                        encryptionMethod = EncryptionMethod.AES
                        aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
                    }
                }

                // Pass 2: Stream directly into ZIP archive without loading whole backup into RAM
                openInputStream()?.buffered(64 * 1024)?.use { stream ->
                    zipFile.addStream(stream, zipParams)
                } ?: throw IllegalStateException("Stream closed unexpectedly for ${item.displayName}")

                currentPartAccumulatedBytes += item.sizeBytes
                totalBytesDone += item.sizeBytes
                completedCount++

                manifestFiles.add(
                    ManifestFileRecord(
                        relativePath = zipParams.fileNameInZip,
                        fileName = item.displayName,
                        categoryId = category.id,
                        mimeType = item.mimeType,
                        sizeBytes = item.sizeBytes,
                        lastModifiedEpochMillis = item.lastModifiedEpochMillis,
                        sha256Checksum = sha256,
                        archivePartName = rawFile.name
                    )
                )

                cacheUpdates.add(
                    IncrementalFileCacheEntity(
                        relativePath = item.relativePath,
                        categoryId = category.id,
                        sizeBytes = item.sizeBytes,
                        lastModifiedEpochMillis = item.lastModifiedEpochMillis,
                        sha256Checksum = sha256,
                        lastBackupId = backupId
                    )
                )

                onProgress(completedCount, item.displayName, totalBytesDone)
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                skipped.add(
                    SkippedFileRecord(
                        relativePath = item.relativePath,
                        categoryId = category.id,
                        reason = "Skipped due to read/archive error: ${e.message ?: "Unknown I/O error"}"
                    )
                )
            }
        }

        // Finalize last open part
        currentZipFileRef?.let { completedFile ->
            if (completedFile.exists() && completedFile.length() > 0L) {
                val sha = ChecksumUtils.computeFileSha256(completedFile)
                generatedParts.add(
                    GeneratedArchivePart(
                        archiveFile = completedFile,
                        category = category,
                        partIndex = currentPartIndex,
                        sizeBytes = completedFile.length(),
                        sha256Checksum = sha,
                        encryptedAes256 = config.encryptArchives && !encryptionPassword.isNullOrEmpty()
                    )
                )
            }
        }

        return CategoryZipBuildResult(
            category = category,
            generatedArchives = generatedParts,
            manifestFileRecords = manifestFiles,
            skippedFiles = skipped,
            updatedCacheEntries = cacheUpdates
        )
    }

    fun sanitizeRelativeEntryPath(rawPath: String): String {
        return rawPath
            .replace("\\", "/")
            .trimStart('/')
            .split("/")
            .filter { it.isNotBlank() && it != "." && it != ".." }
            .joinToString("/")
            .ifBlank { "unnamed_entry" }
    }
}
