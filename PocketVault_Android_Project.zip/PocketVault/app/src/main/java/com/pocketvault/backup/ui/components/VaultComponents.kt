package com.pocketvault.backup.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pocketvault.backup.domain.model.*
import com.pocketvault.backup.ui.theme.VaultColors
import java.util.Locale

object FormatUtils {
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.lastIndex)
        val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
        return String.format(Locale.US, "%.2f %s", value, units[digitGroups])
    }
}

/**
 * 1. Teal Hero Header Component (#042F31 -> #063C3D)
 */
@Composable
fun TealHeroHeader(
    deviceName: String,
    connectedEmail: String?,
    isBangla: Boolean,
    onLanguageToggle: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(VaultColors.HeaderDarkSurface, VaultColors.DeepTealBg)
                ),
                shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
            )
            .padding(horizontal = 24.dp, vertical = 24.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(VaultColors.SoftMint.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudDone,
                            contentDescription = "PocketVault Cloud Logo",
                            tint = VaultColors.SoftMint,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Column {
                        Text(
                            text = if (isBangla) "পকেটভল্ট (PocketVault)" else "PocketVault",
                            color = VaultColors.PureWhite,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = deviceName,
                            color = VaultColors.SoftMint.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onLanguageToggle,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = VaultColors.SoftMint)
                    ) {
                        Text(if (isBangla) "EN" else "বাংলা", fontSize = 12.sp)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = VaultColors.SoftMint
                        )
                    }
                }
            }

            CloudConnectionStatusPill(
                connectedEmail = connectedEmail,
                isBangla = isBangla
            )
        }
    }
}

/**
 * 2. Cloud Connection Status Pill
 */
@Composable
fun CloudConnectionStatusPill(
    connectedEmail: String?,
    isBangla: Boolean
) {
    val isConnected = !connectedEmail.isNullOrBlank()
    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(
                if (isConnected) VaultColors.SuccessAccent.copy(alpha = 0.22f)
                else VaultColors.WarningAmber.copy(alpha = 0.22f)
            )
            .border(
                width = 1.dp,
                color = if (isConnected) VaultColors.SuccessAccent else VaultColors.WarningAmber,
                shape = CircleShape
            )
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isConnected) VaultColors.SuccessAccent else VaultColors.WarningAmber)
        )
        Text(
            text = if (isConnected) {
                if (isBangla) "গুগল ড্রাইভ সংযুক্ত: $connectedEmail" else "Google Drive: $connectedEmail"
            } else {
                if (isBangla) "গুগল ড্রাইভ সংযুক্ত নয়" else "Google Drive Not Connected"
            },
            color = VaultColors.SoftMint,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/**
 * 3. Mint Backup Overview Card (#CFFFF0 / #E4F7F1)
 */
@Composable
fun BackupOverviewCard(
    backupStatusLabel: String,
    isProtected: Boolean,
    lastBackupTimestamp: String?,
    selectedBytes: Long,
    uploadedDriveBytes: Long,
    backedUpFilesCount: Int,
    isBangla: Boolean,
    onBackupNowClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = VaultColors.SoftMint),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isBangla) "ব্যাকআপ সুরক্ষা অবস্থা" else "BACKUP PROTECTION STATUS",
                        color = VaultColors.SecondaryText,
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = backupStatusLabel,
                        color = VaultColors.PrimaryTextOnLight,
                        style = MaterialTheme.typography.headlineMedium
                    )
                }
                Surface(
                    shape = CircleShape,
                    color = if (isProtected) VaultColors.SuccessAccent else VaultColors.DeepTealBg
                ) {
                    Icon(
                        imageVector = if (isProtected) Icons.Default.VerifiedUser else Icons.Default.Shield,
                        contentDescription = null,
                        tint = VaultColors.PureWhite,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Text(
                text = if (lastBackupTimestamp != null) {
                    if (isBangla) "সর্বশেষ সফল ব্যাকআপ: $lastBackupTimestamp"
                    else "Last verified snapshot: $lastBackupTimestamp"
                } else {
                    if (isBangla) "এখনও কোনো ক্লাউড ব্যাকআপ তৈরি করা হয়নি"
                    else "No cloud snapshot created on this device yet"
                },
                color = VaultColors.SecondaryText,
                style = MaterialTheme.typography.bodyMedium
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StorageStatItem(
                    label = if (isBangla) "নির্বাচিত ডেটা" else "Selected Data",
                    value = FormatUtils.formatBytes(selectedBytes)
                )
                StorageStatItem(
                    label = if (isBangla) "ড্রাইভে আপলোড" else "Uploaded to Drive",
                    value = FormatUtils.formatBytes(uploadedDriveBytes)
                )
                StorageStatItem(
                    label = if (isBangla) "সুরক্ষিত ফাইল" else "Backed-Up Files",
                    value = backedUpFilesCount.toString()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                VaultPrimaryButton(
                    text = if (isBangla) "এখনই ব্যাকআপ নিন" else "Back Up Now",
                    icon = Icons.Default.CloudUpload,
                    modifier = Modifier.weight(1f),
                    onClick = onBackupNowClick
                )
                VaultSecondaryButton(
                    text = if (isBangla) "রিস্টোর করুন" else "Restore Backup",
                    icon = Icons.Default.CloudDownload,
                    modifier = Modifier.weight(1f),
                    onClick = onRestoreClick
                )
            }
        }
    }
}

@Composable
fun StorageStatItem(label: String, value: String) {
    Column {
        Text(
            text = value,
            color = VaultColors.PrimaryTextOnLight,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            color = VaultColors.SecondaryText,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/**
 * 4. Category Selection Card
 */
@Composable
fun CategorySelectionCard(
    summary: CategoryScanSummary,
    isBangla: Boolean,
    onToggleSelect: (BackupCategory) -> Unit,
    onInspectCategory: (BackupCategory) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onInspectCategory(summary.category) },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(VaultColors.PaleMintSurface),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconForCategory(summary.category),
                        contentDescription = summary.category.titleEn,
                        tint = VaultColors.DeepTealBg
                    )
                }
                Column {
                    Text(
                        text = if (isBangla) summary.category.titleBn else summary.category.titleEn,
                        color = VaultColors.PrimaryTextOnLight,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${summary.totalItemCount} items • ${FormatUtils.formatBytes(summary.totalSizeBytes)} (Est. ZIP: ${FormatUtils.formatBytes(summary.estimatedBackupSizeBytes)})",
                        color = VaultColors.SecondaryText,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    summary.limitationNote?.let { note ->
                        Text(
                            text = note,
                            color = if (summary.permissionGranted) VaultColors.SecondaryText else VaultColors.WarningAmber,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            Checkbox(
                checked = summary.isSelected,
                onCheckedChange = { onToggleSelect(summary.category) },
                colors = CheckboxDefaults.colors(
                    checkedColor = VaultColors.SuccessAccent,
                    uncheckedColor = VaultColors.SecondaryText
                )
            )
        }
    }
}

/**
 * 5. Primary & Secondary Buttons
 */
@Composable
fun VaultPrimaryButton(
    text: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = VaultColors.DeepTealBg,
            contentColor = VaultColors.PureWhite
        )
    ) {
        Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun VaultSecondaryButton(
    text: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = VaultColors.DeepTealBg
        )
    ) {
        Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, fontWeight = FontWeight.SemiBold)
    }
}

fun iconForCategory(category: BackupCategory): ImageVector = when (category) {
    BackupCategory.PHOTOS -> Icons.Default.PhotoLibrary
    BackupCategory.VIDEOS -> Icons.Default.VideoLibrary
    BackupCategory.SCREENSHOTS -> Icons.Default.Screenshot
    BackupCategory.AUDIO -> Icons.Default.LibraryMusic
    BackupCategory.VOICE_RECORDINGS -> Icons.Default.Mic
    BackupCategory.DOCUMENTS -> Icons.Default.Description
    BackupCategory.DOWNLOADS -> Icons.Default.Download
    BackupCategory.OTHER_FILES -> Icons.Default.FolderOpen
    BackupCategory.USER_FOLDERS -> Icons.Default.CreateNewFolder
    BackupCategory.CONTACTS -> Icons.Default.Contacts
    BackupCategory.CALENDAR -> Icons.Default.Event
    BackupCategory.SMS_CALL_LOGS -> Icons.Default.Sms
}
