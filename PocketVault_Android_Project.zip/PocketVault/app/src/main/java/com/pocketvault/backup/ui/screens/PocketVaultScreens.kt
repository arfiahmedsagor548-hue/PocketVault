package com.pocketvault.backup.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.pocketvault.backup.R
import com.pocketvault.backup.data.local.BackupSnapshotEntity
import com.pocketvault.backup.data.local.OperationLogEntity
import com.pocketvault.backup.domain.model.*
import com.pocketvault.backup.ui.PocketVaultUiState
import com.pocketvault.backup.ui.VaultScreen
import com.pocketvault.backup.ui.components.*
import com.pocketvault.backup.ui.theme.VaultColors

@Composable
fun PocketVaultRootScreen(
    uiState: PocketVaultUiState,
    snapshots: List<BackupSnapshotEntity>,
    logs: List<OperationLogEntity>,
    onNavigate: (VaultScreen) -> Unit,
    onToggleLanguage: () -> Unit,
    onRequestPermissions: () -> Unit,
    onPickSafFolder: () -> Unit,
    onConnectGoogleDrive: () -> Unit,
    onDisconnectGoogleDrive: () -> Unit,
    onToggleCategory: (BackupCategory) -> Unit,
    onInspectCategory: (BackupCategory) -> Unit,
    onUpdateConfig: (BackupConfiguration) -> Unit,
    onStartBackup: (CharArray?) -> Unit,
    onPauseResume: () -> Unit,
    onCancelTask: () -> Unit,
    onRefreshRemoteSnapshots: () -> Unit,
    onSelectConflictStrategy: (ConflictResolutionStrategy, Boolean) -> Unit
) {
    Scaffold(
        containerColor = VaultColors.PaleMintSurface,
        bottomBar = {
            NavigationBar(
                containerColor = VaultColors.PureWhite,
                tonalElevation = 8.dp
            ) {
                val navItems = listOf(
                    Triple(VaultScreen.DASHBOARD, Icons.Default.Dashboard, if (uiState.isBangla) "ড্যাশবোর্ড" else "Dashboard"),
                    Triple(VaultScreen.DATA_EXPLORER, Icons.Default.FolderSpecial, if (uiState.isBangla) "ফাইলসমূহ" else "Explorer"),
                    Triple(VaultScreen.RESTORE_CENTER, Icons.Default.SettingsBackupRestore, if (uiState.isBangla) "রিস্টোর" else "Restore"),
                    Triple(VaultScreen.BACKUP_HISTORY, Icons.Default.History, if (uiState.isBangla) "ইতিহাস" else "History"),
                    Triple(VaultScreen.SETTINGS_SECURITY, Icons.Default.Security, if (uiState.isBangla) "নিরাপত্তা" else "Security")
                )
                navItems.forEach { (screen, icon, label) ->
                    NavigationBarItem(
                        selected = uiState.currentScreen == screen,
                        onClick = { onNavigate(screen) },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = VaultColors.DeepTealBg,
                            selectedTextColor = VaultColors.DeepTealBg,
                            indicatorColor = VaultColors.SoftMint
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TealHeroHeader(
                deviceName = uiState.deviceLabel,
                connectedEmail = uiState.connectedAccountEmail,
                isBangla = uiState.isBangla,
                onLanguageToggle = onToggleLanguage,
                onOpenSettings = { onNavigate(VaultScreen.SETTINGS_SECURITY) }
            )

            // Quick screen selector chips for all 13 functional screens
            ScrollableTabRow(
                selectedTabIndex = VaultScreen.entries.indexOf(uiState.currentScreen).coerceAtLeast(0),
                containerColor = VaultColors.HeaderDarkSurface,
                contentColor = VaultColors.SoftMint,
                edgePadding = 16.dp
            ) {
                VaultScreen.entries.forEach { screen ->
                    Tab(
                        selected = uiState.currentScreen == screen,
                        onClick = { onNavigate(screen) },
                        text = {
                            Text(
                                text = if (uiState.isBangla) screen.titleBn else screen.titleEn,
                                color = if (uiState.currentScreen == screen) VaultColors.SoftMint else VaultColors.SoftMint.copy(alpha = 0.6f)
                            )
                        }
                    )
                }
            }

            when (uiState.currentScreen) {
                VaultScreen.WELCOME -> WelcomeScreenContent(uiState, onNavigate)
                VaultScreen.PERMISSIONS -> PermissionSetupScreenContent(uiState, onRequestPermissions, onPickSafFolder, onNavigate)
                VaultScreen.CONNECT_DRIVE -> ConnectGoogleDriveScreenContent(uiState, onConnectGoogleDrive, onDisconnectGoogleDrive)
                VaultScreen.DASHBOARD -> DashboardScreenContent(
                    uiState = uiState,
                    snapshots = snapshots,
                    onToggleCategory = onToggleCategory,
                    onInspectCategory = onInspectCategory,
                    onBackupNow = { onNavigate(VaultScreen.BACKUP_CONFIG) },
                    onRestoreBackup = {
                        onRefreshRemoteSnapshots()
                        onNavigate(VaultScreen.RESTORE_CENTER)
                    },
                    onOpenHistory = { onNavigate(VaultScreen.BACKUP_HISTORY) }
                )
                VaultScreen.DATA_EXPLORER -> DataExplorerScreenContent(uiState, onPickSafFolder, onToggleCategory)
                VaultScreen.BACKUP_CONFIG -> BackupConfigScreenContent(uiState, onUpdateConfig, onStartBackup)
                VaultScreen.BACKUP_PROGRESS -> BackupProgressScreenContent(uiState, onPauseResume, onCancelTask)
                VaultScreen.BACKUP_HISTORY -> BackupHistoryScreenContent(snapshots, onNavigate)
                VaultScreen.RESTORE_CENTER -> RestoreCenterScreenContent(uiState, snapshots, onRefreshRemoteSnapshots, onNavigate)
                VaultScreen.RESTORE_PREVIEW -> RestorePreviewScreenContent(uiState, onSelectConflictStrategy, onNavigate)
                VaultScreen.RESTORE_PROGRESS -> RestoreProgressScreenContent(uiState, onNavigate)
                VaultScreen.SETTINGS_SECURITY -> SettingsSecurityScreenContent(uiState, onConnectGoogleDrive, onDisconnectGoogleDrive, onToggleLanguage, onNavigate)
                VaultScreen.REPORTS_ERRORS -> ReportsAndErrorsScreenContent(uiState, logs)
            }
        }
    }
}

@Composable
private fun DashboardScreenContent(
    uiState: PocketVaultUiState,
    snapshots: List<BackupSnapshotEntity>,
    onToggleCategory: (BackupCategory) -> Unit,
    onInspectCategory: (BackupCategory) -> Unit,
    onBackupNow: () -> Unit,
    onRestoreBackup: () -> Unit,
    onOpenHistory: () -> Unit
) {
    val selectedBytes = uiState.categories.filter { it.isSelected }.sumOf { it.totalSizeBytes }
    val latestSnapshot = snapshots.firstOrNull()
    val totalUploadedBytes = snapshots.sumOf { it.totalArchiveSizeBytes }
    val totalBackedUpFiles = latestSnapshot?.totalFilesCount ?: 0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            BackupOverviewCard(
                backupStatusLabel = when {
                    latestSnapshot != null -> if (uiState.isBangla) "সুরক্ষিত (Protected)" else "Protected"
                    uiState.connectedAccountEmail == null -> if (uiState.isBangla) "পদক্ষেপ প্রয়োজন" else "Action Required"
                    else -> if (uiState.isBangla) "ব্যাকআপ করা হয়নি" else "Not Backed Up"
                },
                isProtected = latestSnapshot != null,
                lastBackupTimestamp = latestSnapshot?.createdAtFormatted,
                selectedBytes = selectedBytes,
                uploadedDriveBytes = totalUploadedBytes,
                backedUpFilesCount = totalBackedUpFiles,
                isBangla = uiState.isBangla,
                onBackupNowClick = onBackupNow,
                onRestoreClick = onRestoreBackup
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (uiState.isBangla) "ক্যাটাগরি ও স্টোরেজ স্ক্যানার" else "Storage & Category Scanner",
                    style = MaterialTheme.typography.titleLarge,
                    color = VaultColors.PrimaryTextOnLight
                )
                Text(
                    text = "${uiState.categories.count { it.isSelected }}/${uiState.categories.size} selected",
                    style = MaterialTheme.typography.labelMedium,
                    color = VaultColors.SecondaryText
                )
            }
        }

        items(uiState.categories, key = { it.category.id }) { summary ->
            CategorySelectionCard(
                summary = summary,
                isBangla = uiState.isBangla,
                onToggleSelect = onToggleCategory,
                onInspectCategory = onInspectCategory
            )
        }

        if (latestSnapshot != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (uiState.isBangla) "সর্বশেষ যাচাইকৃত স্ন্যাপশট" else "Latest Verified Cloud Snapshot",
                            style = MaterialTheme.typography.titleMedium,
                            color = VaultColors.PrimaryTextOnLight
                        )
                        Text(
                            text = "${latestSnapshot.backupId} • ${FormatUtils.formatBytes(latestSnapshot.totalArchiveSizeBytes)} • ${latestSnapshot.verificationStatus}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = VaultColors.SecondaryText
                        )
                        TextButton(onClick = onOpenHistory) {
                            Text(if (uiState.isBangla) "সম্পূর্ণ ইতিহাস ও রিপোর্ট দেখুন" else "View Snapshot History & HTML Report")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WelcomeScreenContent(uiState: PocketVaultUiState, onNavigate: (VaultScreen) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = if (uiState.isBangla) "পকেটভল্টে স্বাগতম" else "Welcome to PocketVault",
                        style = MaterialTheme.typography.headlineMedium,
                        color = VaultColors.PrimaryTextOnLight
                    )
                    Text(
                        text = stringResource(R.string.privacy_summary),
                        style = MaterialTheme.typography.bodyLarge,
                        color = VaultColors.SecondaryText
                    )
                    VaultPrimaryButton(
                        text = if (uiState.isBangla) "অনুমতি সেটআপ শুরু করুন" else "Continue to Permission Setup",
                        icon = Icons.Default.ArrowForward,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onNavigate(VaultScreen.PERMISSIONS) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionSetupScreenContent(
    uiState: PocketVaultUiState,
    onRequestPermissions: () -> Unit,
    onPickSafFolder: () -> Unit,
    onNavigate: (VaultScreen) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Least-Privilege Storage & Contacts Permissions",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "• MediaStore (Photos, Videos, Audio): Scans shared media without accessing private app sandboxes.
" +
                            "• Storage Access Framework (SAF): Lets you grant access to specific document folders.
" +
                            "• Contacts & Calendar: Exports standard Contacts.vcf and Calendar.ics files.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VaultColors.SecondaryText
                    )
                    VaultPrimaryButton(
                        text = "Grant Runtime Permissions",
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onRequestPermissions
                    )
                    VaultSecondaryButton(
                        text = "Select Custom Folder (SAF)",
                        icon = Icons.Default.CreateNewFolder,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onPickSafFolder
                    )
                    TextButton(onClick = { onNavigate(VaultScreen.CONNECT_DRIVE) }) {
                        Text("Next: Connect Google Drive →")
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectGoogleDriveScreenContent(
    uiState: PocketVaultUiState,
    onConnectGoogleDrive: () -> Unit,
    onDisconnectGoogleDrive: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Direct Google Drive API v3 Integration", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Scope: https://www.googleapis.com/auth/drive.file
" +
                            "Root Folder: PocketVault Backups/<Device_Name>/<Timestamp>/
" +
                            "PocketVault can only access folders and archives it creates—never unrelated Drive files.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VaultColors.SecondaryText
                    )
                    if (!uiState.oauthClientConfigured) {
                        Surface(
                            color = VaultColors.PaleMintSurface,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Configuration Notice: Configure your debug/release SHA-1 fingerprint and OAuth 2.0 Client ID in Google Cloud Console (see README.md) to enable live Google Sign-In on your device.",
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodyMedium,
                                color = VaultColors.PrimaryTextOnLight
                            )
                        }
                    }
                    if (uiState.connectedAccountEmail == null) {
                        VaultPrimaryButton(
                            text = "Connect Google Account",
                            icon = Icons.Default.AccountCircle,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = onConnectGoogleDrive
                        )
                    } else {
                        Text(
                            text = "Connected as: ${uiState.connectedAccountEmail}",
                            fontWeight = FontWeight.SemiBold,
                            color = VaultColors.SuccessAccent
                        )
                        uiState.driveQuota?.let { quota ->
                            Text(
                                text = "Available Drive Storage: ${FormatUtils.formatBytes(quota.availableBytes)} free of ${FormatUtils.formatBytes(quota.limitBytes)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        VaultSecondaryButton(
                            text = "Disconnect Account (Keep Local History)",
                            icon = Icons.Default.Logout,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = onDisconnectGoogleDrive
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DataExplorerScreenContent(
    uiState: PocketVaultUiState,
    onPickSafFolder: () -> Unit,
    onToggleCategory: (BackupCategory) -> Unit
) {
    val activeSummary = uiState.categories.find { it.category == uiState.selectedCategoryForExplorer }
        ?: uiState.categories.firstOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = activeSummary?.category?.titleEn ?: "Data Explorer",
                    style = MaterialTheme.typography.titleLarge
                )
                OutlinedButton(onClick = onPickSafFolder) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Add SAF Folder")
                }
            }
        }
        if (activeSummary != null) {
            if (activeSummary.files.isEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)) {
                        Text(
                            text = activeSummary.limitationNote ?: "No accessible files found in this category.",
                            modifier = Modifier.padding(20.dp),
                            color = VaultColors.SecondaryText
                        )
                    }
                }
            } else {
                items(activeSummary.files.take(100), key = { it.id }) { fileItem ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(fileItem.displayName, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${fileItem.relativePath} • ${FormatUtils.formatBytes(fileItem.sizeBytes)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = VaultColors.SecondaryText
                                )
                            }
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = VaultColors.SuccessAccent)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BackupConfigScreenContent(
    uiState: PocketVaultUiState,
    onUpdateConfig: (BackupConfiguration) -> Unit,
    onStartBackup: (CharArray?) -> Unit
) {
    var passwordText by remember { mutableStateOf("") }
    var confirmPasswordText by remember { mutableStateOf("") }
    val config = uiState.backupConfig

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Backup Mode & Archive Splitting", style = MaterialTheme.typography.titleLarge)
                    BackupMode.entries.forEach { mode ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onUpdateConfig(config.copy(mode = mode)) }
                        ) {
                            RadioButton(
                                selected = config.mode == mode,
                                onClick = { onUpdateConfig(config.copy(mode = mode)) }
                            )
                            Text(if (uiState.isBangla) mode.labelBn else mode.labelEn)
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Encrypt ZIP Archives (AES-256)", fontWeight = FontWeight.SemiBold)
                            Text(
                                stringResource(R.string.encryption_warning),
                                style = MaterialTheme.typography.bodyMedium,
                                color = VaultColors.SecondaryText
                            )
                        }
                        Switch(
                            checked = config.encryptArchives,
                            onCheckedChange = { onUpdateConfig(config.copy(encryptArchives = it)) }
                        )
                    }

                    if (config.encryptArchives) {
                        OutlinedTextField(
                            value = passwordText,
                            onValueChange = { passwordText = it },
                            label = { Text("Backup Password (min 8 chars, letters + numbers)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = confirmPasswordText,
                            onValueChange = { confirmPasswordText = it },
                            label = { Text("Confirm Backup Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Wi-Fi Only (Unmetered Network)")
                        Switch(
                            checked = config.wifiOnly,
                            onCheckedChange = { onUpdateConfig(config.copy(wifiOnly = it)) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Charging Only")
                        Switch(
                            checked = config.chargingOnly,
                            onCheckedChange = { onUpdateConfig(config.copy(chargingOnly = it)) }
                        )
                    }

                    VaultPrimaryButton(
                        text = "Start Verified Backup Now",
                        icon = Icons.Default.CloudUpload,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !config.encryptArchives || (passwordText.length >= 8 && passwordText == confirmPasswordText),
                        onClick = {
                            onStartBackup(if (config.encryptArchives) passwordText.toCharArray() else null)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun BackupProgressScreenContent(
    uiState: PocketVaultUiState,
    onPauseResume: () -> Unit,
    onCancelTask: () -> Unit
) {
    val prog = uiState.activeProgress
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
        ) {
            Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(prog.currentPhaseTitle, style = MaterialTheme.typography.titleLarge)
                LinearProgressIndicator(
                    progress = { prog.overallFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp),
                    color = VaultColors.SuccessAccent,
                    trackColor = VaultColors.PaleMintSurface
                )
                Text(
                    "Category: ${prog.currentCategory.ifBlank { "All Selected" }} • File: ${prog.currentFileName.ifBlank { "Complete" }}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = VaultColors.SecondaryText
                )
                Text(
                    "Processed: ${prog.completedFiles}/${prog.totalFiles} files (${FormatUtils.formatBytes(prog.processedBytes)} / ${FormatUtils.formatBytes(prog.totalEstimatedBytes)})",
                    fontWeight = FontWeight.SemiBold
                )
                if (prog.isRunning) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        VaultSecondaryButton(
                            text = if (prog.isPaused) "Resume" else "Pause",
                            icon = if (prog.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            modifier = Modifier.weight(1f),
                            onClick = onPauseResume
                        )
                        VaultSecondaryButton(
                            text = "Cancel",
                            icon = Icons.Default.Cancel,
                            modifier = Modifier.weight(1f),
                            onClick = onCancelTask
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BackupHistoryScreenContent(
    snapshots: List<BackupSnapshotEntity>,
    onNavigate: (VaultScreen) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Local & Cloud Snapshot History", style = MaterialTheme.typography.titleLarge)
        }
        if (snapshots.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)) {
                    Text(
                        "No backups recorded yet. Run 'Back Up Now' from the Dashboard to create your first verified snapshot.",
                        modifier = Modifier.padding(20.dp),
                        color = VaultColors.SecondaryText
                    )
                }
            }
        } else {
            items(snapshots, key = { it.backupId }) { snap ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${snap.createdAtFormatted} (${snap.deviceLabel})", fontWeight = FontWeight.Bold)
                        Text("Snapshot ID: ${snap.backupId} • ${snap.totalFilesCount} files • ${FormatUtils.formatBytes(snap.totalArchiveSizeBytes)}")
                        Text(
                            "Categories: ${snap.categoriesCsv} • Status: ${snap.verificationStatus} • AES-256: ${if (snap.encryptedAes256) "Yes" else "No"}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = VaultColors.SecondaryText
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RestoreCenterScreenContent(
    uiState: PocketVaultUiState,
    localSnapshots: List<BackupSnapshotEntity>,
    onRefreshRemote: () -> Unit,
    onNavigate: (VaultScreen) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = VaultColors.SoftMint)) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Restore Center — Cross-Device Snapshot Discovery", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "After a factory reset or on a new phone, connect the same Google account to automatically discover all snapshots inside 'PocketVault Backups' without needing the original phone.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    VaultPrimaryButton(
                        text = "Scan Google Drive for Backups",
                        icon = Icons.Default.Refresh,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onRefreshRemote
                    )
                }
            }
        }
        items(localSnapshots, key = { it.backupId }) { snap ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(VaultScreen.RESTORE_PREVIEW) },
                colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Snapshot ${snap.createdAtFormatted} • ${snap.deviceLabel}", fontWeight = FontWeight.Bold)
                    Text("${snap.totalFilesCount} files • ${FormatUtils.formatBytes(snap.totalArchiveSizeBytes)} • Integrity: ${snap.verificationStatus}")
                    TextButton(onClick = { onNavigate(VaultScreen.RESTORE_PREVIEW) }) {
                        Text("Preview & Restore Snapshot →")
                    }
                }
            }
        }
    }
}

@Composable
private fun RestorePreviewScreenContent(
    uiState: PocketVaultUiState,
    onSelectConflictStrategy: (ConflictResolutionStrategy, Boolean) -> Unit,
    onNavigate: (VaultScreen) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Restore Preview & Conflict Resolution", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Available Device Storage: ${FormatUtils.formatBytes(uiState.availableLocalStorageBytes)}
" +
                            "Target Restore Folders:
" +
                            "• Photos → Pictures/PocketVault
" +
                            "• Videos → Movies/PocketVault
" +
                            "• Documents → Documents/PocketVault
" +
                            "• Contacts → Contacts Provider (with duplicate check)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = VaultColors.SecondaryText
                    )
                    Text("Filename Conflict Handling:", fontWeight = FontWeight.SemiBold)
                    ConflictResolutionStrategy.entries.forEach { strategy ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectConflictStrategy(strategy, uiState.userConfirmedOverwrite) }
                        ) {
                            RadioButton(
                                selected = uiState.selectedConflictStrategy == strategy,
                                onClick = { onSelectConflictStrategy(strategy, uiState.userConfirmedOverwrite) }
                            )
                            Column {
                                Text(strategy.labelEn, fontWeight = FontWeight.Medium)
                                Text(strategy.descriptionEn, style = MaterialTheme.typography.bodyMedium, color = VaultColors.SecondaryText)
                            }
                        }
                    }
                    VaultPrimaryButton(
                        text = "Verify SHA-256 & Restore Selected Data",
                        icon = Icons.Default.CloudDownload,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onNavigate(VaultScreen.RESTORE_PROGRESS) }
                    )
                }
            }
        }
    }
}

@Composable
private fun RestoreProgressScreenContent(
    uiState: PocketVaultUiState,
    onNavigate: (VaultScreen) -> Unit
) {
    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Restoration & SHA-256 Verification", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Every archive is checked against its manifest SHA-256 digest and inspected for Zip-Slip path safety before any file is written to Pictures/PocketVault or Documents/PocketVault.",
                    color = VaultColors.SecondaryText
                )
                VaultSecondaryButton(
                    text = "View Detailed Restoration Report",
                    icon = Icons.Default.Assessment,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onNavigate(VaultScreen.REPORTS_ERRORS) }
                )
            }
        }
    }
}

@Composable
private fun SettingsSecurityScreenContent(
    uiState: PocketVaultUiState,
    onConnectGoogleDrive: () -> Unit,
    onDisconnectGoogleDrive: () -> Unit,
    onToggleLanguage: () -> Unit,
    onNavigate: (VaultScreen) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Security, Localization & App Inventory", style = MaterialTheme.typography.titleLarge)
                    Text(stringResource(R.string.privacy_summary), style = MaterialTheme.typography.bodyMedium, color = VaultColors.SecondaryText)
                    HorizontalDivider()
                    Text("Installed App Inventory (${uiState.installedApps.size} User Apps)", fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.sandbox_limitation_notice), style = MaterialTheme.typography.bodyMedium, color = VaultColors.SecondaryText)
                    VaultSecondaryButton(
                        text = if (uiState.isBangla) "Switch to English" else "বাংলা ভাষায় পরিবর্তন করুন (Bangla)",
                        icon = Icons.Default.Language,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onToggleLanguage
                    )
                }
            }
        }
    }
}

@Composable
private fun ReportsAndErrorsScreenContent(
    uiState: PocketVaultUiState,
    logs: List<OperationLogEntity>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Verification Reports & Diagnostic Logs", style = MaterialTheme.typography.titleLarge)
        }
        if (logs.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)) {
                    Text("No errors or warnings recorded.", modifier = Modifier.padding(20.dp))
                }
            }
        } else {
            items(logs, key = { it.id }) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = VaultColors.PureWhite)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("[${log.severity}] ${log.title}", fontWeight = FontWeight.Bold)
                        Text(log.details, style = MaterialTheme.typography.bodyMedium)
                        Text("Next step: ${log.suggestedAction}", style = MaterialTheme.typography.labelMedium, color = VaultColors.SecondaryText)
                    }
                }
            }
        }
    }
}
