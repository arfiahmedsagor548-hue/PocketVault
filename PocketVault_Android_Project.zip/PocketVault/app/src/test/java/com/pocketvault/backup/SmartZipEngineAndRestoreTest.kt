package com.pocketvault.backup

import com.pocketvault.backup.data.security.ChecksumUtils
import com.pocketvault.backup.data.zip.BackupReportGenerator
import com.pocketvault.backup.data.zip.SmartZipRestoreEngine
import com.pocketvault.backup.domain.model.*
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SmartZipEngineAndRestoreTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun `test SHA-256 verification and corruption detection`() {
        val sampleFile = tempFolder.newFile("photo_sample.jpg")
        sampleFile.writeText("PocketVault binary image payload 2026")

        val expectedSha = ChecksumUtils.computeFileSha256(sampleFile)
        assertTrue(ChecksumUtils.verifyFileSha256(sampleFile, expectedSha))

        // Modify file and confirm integrity verification fails
        sampleFile.appendText("-tampered")
        assertFalse(ChecksumUtils.verifyFileSha256(sampleFile, expectedSha))
    }

    @Test
    fun `test AES-256 encrypted archive blocks wrong password and extracts with correct password`() {
        val staging = tempFolder.newFolder("encrypted_staging")
        val restoreDir = tempFolder.newFolder("restore_out")
        val plainDoc = File(staging, "secret_notes.txt").apply {
            writeText("Sensitive financial backup record")
        }
        val plainHash = ChecksumUtils.computeFileSha256(plainDoc)

        val zipPath = File(staging, "Documents_001.zip")
        val correctPassword = "Vault2026StrongPassword".toCharArray()
        val wrongPassword = "WrongPassword123".toCharArray()

        val zipFile = ZipFile(zipPath, correctPassword)
        val params = ZipParameters().apply {
            fileNameInZip = "Documents/secret_notes.txt"
            isEncryptFiles = true
            encryptionMethod = EncryptionMethod.AES
            aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
        }
        zipFile.addFile(plainDoc, params)
        val archiveSha = ChecksumUtils.computeFileSha256(zipPath)

        val restoreEngine = SmartZipRestoreEngine()

        // 1. Verify extraction fails with WrongPasswordException when given wrong password
        try {
            restoreEngine.verifyAndExtractArchive(
                archiveFile = zipPath,
                expectedArchiveSha256 = archiveSha,
                destinationRootDir = restoreDir,
                password = wrongPassword
            )
            fail("Expected WrongPasswordException when using wrong password")
        } catch (e: SmartZipRestoreEngine.WrongPasswordException) {
            assertTrue(e.message!!.contains("Incorrect decryption password"))
        }

        // 2. Verify extraction succeeds and verifies file-level SHA-256 with correct password
        val manifestMap = mapOf(
            "Documents/secret_notes.txt" to ManifestFileRecord(
                relativePath = "Documents/secret_notes.txt",
                fileName = "secret_notes.txt",
                categoryId = BackupCategory.DOCUMENTS.id,
                mimeType = "text/plain",
                sizeBytes = plainDoc.length(),
                lastModifiedEpochMillis = plainDoc.lastModified(),
                sha256Checksum = plainHash,
                archivePartName = "Documents_001.zip"
            )
        )

        val result = restoreEngine.verifyAndExtractArchive(
            archiveFile = zipPath,
            expectedArchiveSha256 = archiveSha,
            destinationRootDir = restoreDir,
            expectedFileChecksums = manifestMap,
            password = correctPassword
        )

        assertEquals(1, result.restoredFiles.size)
        assertEquals(1, result.checksumVerifiedCount)
        assertTrue(result.failedEntries.isEmpty())
    }

    @Test
    fun `test conflict resolution RENAME_RESTORED never overwrites existing local file`() {
        val staging = tempFolder.newFolder("conflict_staging")
        val restoreDir = tempFolder.newFolder("conflict_restore")

        val sourceFile = File(staging, "family.jpg").apply { writeText("New Restored Copy") }
        val existingTarget = File(restoreDir, "Pictures/family.jpg").apply {
            parentFile?.mkdirs()
            writeText("Original Local File Untouched")
        }

        val zipFile = ZipFile(File(staging, "Photos_001.zip"))
        zipFile.addFile(sourceFile, ZipParameters().apply { fileNameInZip = "Pictures/family.jpg" })

        val restoreEngine = SmartZipRestoreEngine()
        val res = restoreEngine.verifyAndExtractArchive(
            archiveFile = zipFile.file,
            expectedArchiveSha256 = ChecksumUtils.computeFileSha256(zipFile.file),
            destinationRootDir = restoreDir,
            conflictStrategy = ConflictResolutionStrategy.RENAME_RESTORED
        )

        // Original file must remain completely untouched
        assertEquals("Original Local File Untouched", existingTarget.readText())
        // Restored copy must be saved under _restored_1 suffix
        val renamedFile = File(restoreDir, "Pictures/family_restored_1.jpg")
        assertTrue(renamedFile.exists())
        assertEquals("New Restored Copy", renamedFile.readText())
        assertEquals(1, res.restoredFiles.size)
    }

    @Test
    fun `test manifest serialization never leaks passwords or tokens`() {
        val manifest = BackupManifest(
            backupId = "PV-2026-10-21_13-40-00",
            deviceLabel = "Pixel_8_Pro",
            androidSdkInt = 34,
            androidRelease = "14",
            createdAtIso = "2026-10-21_13-40-00",
            createdAtEpochMillis = 1792568400000L,
            backupMode = BackupMode.FULL.name,
            encryptedAes256 = true,
            selectedCategories = listOf("photos", "contacts"),
            categoryStatuses = mapOf("photos" to "PROTECTED", "contacts" to "PROTECTED"),
            totalFilesCount = 1,
            totalRawBytes = 2048L,
            totalArchiveBytes = 2048L,
            archives = emptyList(),
            files = emptyList(),
            skippedFiles = emptyList()
        )
        val outFile = tempFolder.newFile("backup_manifest.json")
        val json = BackupReportGenerator.writeManifestJson(manifest, outFile)
        assertFalse(json.contains("password", ignoreCase = true))
        assertFalse(json.contains("access_token", ignoreCase = true))

        val parsed = BackupReportGenerator.parseManifestJson(json)
        assertEquals("PV-2026-10-21_13-40-00", parsed.backupId)
        assertTrue(parsed.encryptedAes256)
    }
}
